from time import sleep
from tkinter.filedialog import askopenfilename
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement 
from selenium.common.exceptions import *
from Imputaciones import Imputacion

import os

class Bot():

    vpn:bool = False
    userProduce:str
    passProduce:str
    userZS:str
    passZS:str

    def __init__(self,vpn:bool,userProduce:str,passProduce:str,userZS:str=None,passZS:str=None) -> None:
        self.vpn = vpn
        self.userProduce=userProduce
        self.passProduce=passProduce
        self.userZS=userZS
        self.passZS=passZS
        self.initProps()
        if not vpn:
            self.byPassIntranet()
        self.manageProduce()
        self.leerFichero()

    def initProps(self):
        if self.vpn:
            self.url_produce = "https://produce.viewnext.com/produce/do/login"
            self.url_produce_home = "https://produce.viewnext.com/produce/do/view/preprincipal?aleat=0.08351092456268738"
        else:
            self.url_scape_intranet = "https://mi.viewnext.com/dana-na/auth/url_default/welcome.cgi"
            self.url_produce = "https://mi.viewnext.com/produce/do/,DanaInfo=.apsqgyhkG3ro7zr.8Pt65,SSL+login"
            self.url_produce_home = "https://mi.viewnext.com/produce/do/view/,DanaInfo=.apsqgyhkG3ro7zr.8Pt65,SSL+preprincipal"

        self.chrome_options = Options()
        self.chrome_options.add_experimental_option("detach", True)
        self.browser = webdriver.Chrome(options=self.chrome_options)
        self.browser.maximize_window()
        self.imputacion = Imputacion(self.browser,2)

    def byPassIntranet(self):#PDT REVISION
        self.browser.get(self.url_scape_intranet)
        sleep(0.5)
        self.inpU = self.browser.find_element(By.NAME,"loginfmt")
        self.inpU.send_keys(self.userZS)
        self.browser.find_element(By.ID,"idSIButton9").click()
        #class=>progress id=>progressBar
        #antes de pasar a la pasword es posible que haya un loading, verlo y esperarlo antes de obtener y mandar
        inpP = self.browser.find_element(By.NAME,"passwd")
        inpP.send_keys(self.passZS)
        sleep(1)
        self.browser.find_element(By.ID,"idSIButton9").click()
        sleep(1.5)
        self.waitUntilUser2FA()
        #cambiar y hacer que espere hasta que carge
        sleep(3)
        self.browser.execute_script("gowelcome()")
        self.browser.execute_script("gowelcome()")
        self.browser.find_element(By.ID,"btnContinue").click()
            
    def waitUntilUser2FA(self):
        while(True):
            try:
                self.browser.find_element(By.ID,"idTxtBx_SAOTCC_OTC")
                sleep(0.3)
            except:
                break
            
    def manageProduce(self):
        self.browser.get(self.url_produce)
        self.browser.find_element(By.NAME,"userId").send_keys(self.userProduce)
        self.browser.find_element(By.NAME,"password").send_keys(self.passProduce)
        self.browser.find_element(By.CLASS_NAME,"submit").click()

    def leerFichero(self):
        filename_list = askopenfilename(multiple=True,filetypes=[('txt','*.txt')])
        for filename in filename_list:
            remedysNoDisponiblesAun = ""
            fecha = os.path.basename(filename)
            fecha1 = fecha[4:8]+"-"+fecha[2:4]+"-"+fecha[0:2]
            print("leyendo de: "+fecha1)
            procesable = self.imputacion.controlTotalHoras(fecha1)
            if procesable:
                file = open(filename, "r")
                for linea in file:
                    spliteo = linea.split(";")
                    longitud = len(spliteo)
                    if longitud<2 or longitud >3:
                        print("no se puede realizar imputación con los datos introducidos")
                    else:
                        self.imputacion.posicionarMes(fecha)
                        self.browser.execute_script("window.scrollTo(0, document.body.scrollHeight)")
                        if not self.imputacion.controlRemedyYaImputado(fecha1,spliteo[0]):
                            result = self.imputacion.manageRemedy(spliteo[0],spliteo[1],None if longitud == 2 else spliteo[2],fecha)
                            if result!=None:
                                remedysNoDisponiblesAun=remedysNoDisponiblesAun+result
                            self.browser.get(self.url_produce_home)
                            self.imputacion.waitPage(self.browser.find_element(By.ID,"loading"))
                        else:
                            print("remedy "+spliteo[0]+" ya imputado")
                if remedysNoDisponiblesAun=="":
                    self.imputacion.completarHasta8H(fecha)
                else:
                    self.browser.get(self.url_produce_home)
                    self.imputacion.remedysNoDisponible(fecha,remedysNoDisponiblesAun)
                self.browser.get(self.url_produce_home)
                self.imputacion.waitPage(self.browser.find_element(By.ID,"loading"))
            else:
                print("ya se han alcanzado el total de horas y no se puede imputar más")